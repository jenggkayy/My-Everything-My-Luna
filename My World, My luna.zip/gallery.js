function uploadPhoto() {
    const fileInput = document.getElementById("uploadImage");
    const gallery = document.getElementById("gallery");

    if (fileInput.files.length > 0) {
        const reader = new FileReader();
        reader.onload = function (event) {
            const imgDiv = document.createElement("div");
            imgDiv.classList.add("polaroid");

            const img = document.createElement("img");
            img.src = event.target.result;
            img.classList.add("gallery-image");

            imgDiv.appendChild(img);
            gallery.appendChild(imgDiv);
        };
        reader.readAsDataURL(fileInput.files[0]);
    }
}
