 document.addEventListener("DOMContentLoaded", function () {
    const entries = document.querySelectorAll(".entry"); // Kukunin lahat ng diary entries

    entries.forEach((entry) => {
        let pressTimer; // Variable para malaman kung matagal ang pindot

        entry.addEventListener("mousedown", function () {
            pressTimer = setTimeout(() => {
                const confirmDelete = confirm("Are you sure you want to delete this entry?");
                if (confirmDelete) {
                    entry.remove(); // Tatanggalin ang entry kapag na-confirm
                }
            }, 800); // 800ms (0.8 seconds) bago lumabas ang delete confirmation
        });

        entry.addEventListener("mouseup", function () {
            clearTimeout(pressTimer); // Hindi itutuloy ang delete kapag hindi long press
        });

        entry.addEventListener("mouseleave", function () {
            clearTimeout(pressTimer); // Hindi rin itutuloy kapag iniwan ang entry bago matapos ang 800ms
        });
    });
});
